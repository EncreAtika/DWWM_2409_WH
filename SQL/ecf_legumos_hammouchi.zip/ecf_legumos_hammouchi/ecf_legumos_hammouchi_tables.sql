USE ecf_legumos_hammouchi;

INSERT INTO VEGETABLES 
(id, vName, variety, primaryColor, lifeTime, fresh, price)
VALUES
(1, "apple", "golden", "green", 90, 0, 2.5),
(2, "banana", "cavendish", "yellow", 10, 0, 3.99),
(3, "blueberries", "bluecrop", "green", 8, 1, 2.99),
(4, "cabbage", "broccoli", "green", 60, 0, 1.49),
(5, "carrot", "de Colmar", "orange", 60, 0, 1.59),
(6, "cherry", "moreau", "darkred", 20, 0, 1.99),
(7, "coconut", "palmyre", "brown", 30, 0, 3.95),
(8, "grape", "aladin", "green", 10, 1, 1.95),
(9, "kiwi", "hayward", "green", 40, 1, 2.45),
(10 ,"lemon", "eureka", "green", 30, 0, 3.15),
(11, "onion", "Stuttgart", "white", 90, 0, 1.25);

INSERT INTO SALES
(saleDate, saleWeight, saleUnitPrice, saleActive,id)
VALUES 
("2025-01-28", 25000, 98.75, 1, 7),
("2025-01-27", 40000, 50, 0, 11),
("2025-01-27", 100000, 299, 1, 3),
("2025-01-26", 75000, 296.25, 1, 7),
("2025-01-25", 98200, 245.5, 0, 1);

