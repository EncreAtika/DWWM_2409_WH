DROP DATABASE IF EXISTS ecf_legumos_hammouchi;
CREATE DATABASE ecf_legumos_hammouchi;
USE ecf_legumos_hammouchi;

CREATE TABLE VEGETABLES (
id INT(11) PRIMARY KEY NOT NULL,
vName VARCHAR(50) NOT NULL,
/* "name" apparaît comme étant un mot reservé, je préfère donc d'utiliser le terme vName),
mais j'ai mis le bon mot dans les requêtes en utilisant un allias*/
variety VARCHAR(50) NOT NULL,
primaryColor VARCHAR(20) NOT NULL,
lifeTime INT(11) NOT NULL,
fresh INT(1) NOT NULL,
price DECIMAL(5,2)
);

CREATE TABLE SALES (
saleid INT(11) AUTO_INCREMENT ,
saleDate DATE NOT NULL,
saleWeight INT(11) NOT NULL,
saleUnitPrice DECIMAL(5,2) NOT NULL,
saleActive SMALLINT(1) NOT NULL,
id INT(11),
PRIMARY KEY(saleid),
FOREIGN KEY(id) REFERENCES VEGETABLES(id) 
);
