USE ecf_legumos_hammouchi;

-- 1/ Sélectionner toutes les informations des légumes triés par nom du légume (ordre alphabétique) :
SELECT id, vName AS "Name", variety, primaryColor, lifeTime, fresh, price
FROM VEGETABLES
ORDER BY vName ASC;

-- 2/ Sélectionner le nom et le prix des légumes. Pour chaque variété de légume, afficher le nombre de
-- ventes ainsi que le poids total vendu. Les légumes sont triés par nombre de ventes.
SELECT v.vName AS "Name", v.price, SUM(s.saleWeight), COUNT(s.saleActive)
FROM VEGETABLES v
JOIN SALES s ON v.id = s.id 
GROUP BY v.vName, v.price
;
 

-- 3/ Sélectionner le nom, la variété, la couleur, le prix au kilo des légumes dont la couleur principale est verte 
SELECT vName as "Name", variety, primaryColor, price
FROM VEGETABLES
WHERE vName LIKE "%on%" OR primaryColor = "green";

-- 4/ Sélectionner les légumes avec pour chaque légume :
-- a. Son nom.
-- b. Sa varité.
-- c. La somme totale des ventes pour la varité de ce légume.
-- d. Le poid moyen d'une vente.
-- e. Le poid et le prix de la vente la plus élevée.
SELECT v.vName AS "Name", v.variety AS "Variété", 
	   SUM(s.saleUnitPrice) AS "Somme Total",ROUND(AVG(s.saleWeight)) AS "Poid Moyen/vente", MAX(s.saleWeight) AS "Poid vente plus elevé", Max(s.saleUnitPrice) AS "Prix de la vente la plus élevée"
FROM VEGETABLES v
JOIN SALES s ON v.id = s.id
GROUP BY v.vName, v.variety;




